/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>

int32 enteros[3];
float32 VoltsADC[3];
char str[12],str2[12];
char recibir;

int canal=0;

CY_ISR(Enviar)
{
    if (canal==0)
    {
        sprintf(str2,"%.3f \n \r",VoltsADC[0]);
        UART_PutString(str2);
    }
     if (canal==1)
    {
        sprintf(str2,"%.3f \n \r",VoltsADC[1]);
        UART_PutString(str2);
    }
     if (canal==2)
    {
        sprintf(str2,"%.3f \n \r",VoltsADC[2]);
        UART_PutString(str2);
    }
}

CY_ISR(InterruptRX)
{
    recibir = UART_GetChar();
    
    if(recibir == '0')
    {
        canal=0;
    }
    
    if(recibir == '1')
    {
        canal=1;
    }
    
    if(recibir == '2')
    {
        canal=2;
    }
}

int main(void)
{
    CyGlobalIntEnable; 
    
    PWM_Start();
    LCD_Start();
    LCD_Position(0,0);
    LCD_PrintString("Ejemplo ADC+UART FD");
    AMux_Start();
    ADC_Start();
    UART_Start();
    
    isrRX_StartEx(InterruptRX);
    isrEnvio_StartEx(Enviar);
    
    for(;;)
    {
        AMux_FastSelect(0);
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        enteros[0]=ADC_GetResult32();
        ADC_StopConvert();
        
        AMux_FastSelect(1);
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        enteros[1]=ADC_GetResult32();
        ADC_StopConvert();
        
        AMux_FastSelect(2);
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        enteros[2]=ADC_GetResult32();
        ADC_StopConvert();
        
        VoltsADC[0] = ADC_CountsTo_Volts(enteros[0]);
        VoltsADC[1] = ADC_CountsTo_Volts(enteros[1]);
        VoltsADC[2] = ADC_CountsTo_Volts(enteros[2]);
        
        sprintf(str,"%.3f ",VoltsADC[0]);
        LCD_Position(1,0);
        LCD_PrintString("A0: ");
        LCD_PrintString(str);
        
        sprintf(str,"%.3f ",VoltsADC[1]);
        LCD_Position(1,11);
        LCD_PrintString("A1: ");
        LCD_PrintString(str);
        
        sprintf(str,"%.3f ",VoltsADC[2]);
        LCD_Position(2,5);
        LCD_PrintString("A2: ");
        LCD_PrintString(str);
        
        LCD_Position(3,5);
        LCD_PrintString("Canal: ");
        LCD_PrintNumber(canal);
        
    }
}

/* [] END OF FILE */
