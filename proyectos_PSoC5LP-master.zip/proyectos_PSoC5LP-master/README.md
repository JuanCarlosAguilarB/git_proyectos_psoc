# Proyectos prácticos con PSOC5LP

Este es el repositorio oficial del libro titulado "Proyectos prácticos con PSOC5LP" y aquí estarán todos los archivos relacionados a los proyectos (codigo fuente y proyecto), para que puedan ser consultados. 
